export default function Home() {
  return <h1 className="text-2xl font-bold p-4">Velkommen til Skærmstyring.dk</h1>;
}
