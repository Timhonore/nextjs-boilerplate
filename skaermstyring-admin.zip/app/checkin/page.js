export default function CheckIn() {
  return <div className="p-4">Check-in modul: Nummerpladebaseret tjek-ind vises her.</div>;
}
