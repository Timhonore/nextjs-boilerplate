export default function Screens() {
  return <div className="p-4">Skærmliste: Her kommer oversigten over skærmenheder.</div>;
}
